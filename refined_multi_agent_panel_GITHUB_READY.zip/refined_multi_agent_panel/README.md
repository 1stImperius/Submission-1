# Refined Multi-Agent AI Interview Panel

Reference implementation aligned to the supplied assignment:

- candidate profile builder from resume + interview transcript
- four distinct epistemic personas
- isolated blind initial evaluations
- every established score tied to evidence
- explicit `NOT_ESTABLISHED` state; no score when evidence is insufficient
- fixed four-edge debate ring so debate is unconditional
- adaptive extra debate edges for severe cross-persona disagreement
- validated post-debate revisions and explicit revision deltas
- deterministic mandatory gates and bounded scoring
- per-candidate final reports
- comparative final reasoning that is not simple averaging
- Python enforcement prevents an ineligible candidate from being selected
- candidate-isolated evidence stores
- reproducibility fingerprint helper

The LLM provider is deliberately abstracted behind `LLMClient`. This prevents provider-specific SDK details from becoming part of the verification architecture.

## Run tests

```bash
pip install pydantic pytest
pytest -q
```

## Real provider

Implement `LLMClient.complete_json` and `complete_text` for the provider/model of your choice. Do not remove the validation calls after LLM responses.

## Important design rule

One Python `Agent` class is intentional. Independence comes from immutable persona configurations and execution isolation—not duplicated class definitions. Initial calls never receive another agent's conclusions.
